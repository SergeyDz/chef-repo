## 1.0.1 / 2014-03-03

### New features

* Pull request [#7][]: Add retry logic to exhibitor discover zookeepers. ([@rayrod2030][])

## 1.0.0 / 2014-01-31

### New features

* Pull request [#6][]: Prep cookbook for open source release. ([@rayrod2030][])

## 0.1.2 / 2013-10-07

### New features

* Pull request [#1][]: Added zookeeper configuration logic. ([@rayrod2030][])
* Pull request [#2][]: Updated README. ([@rayrod2030][])

[#1]: https://github.com/mdsol/chronos_cookbook/pull/1
[#2]: https://github.com/mdsol/chronos_cookbook/pull/2
[#6]: https://github.com/mdsol/chronos_cookbook/pull/6
[#7]: https://github.com/mdsol/chronos_cookbook/pull/7

[@rayrod2030]: https://github.com/rayrod2030
